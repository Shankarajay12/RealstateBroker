package com.realestate.web.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.realestate.entity.Admin;
import com.realestate.entity.User;
import com.realestate.service.UserService;

@Controller
public class HomeController {
	
	@Autowired
	private UserService userservice;
	
	User user=new User();
	
	@RequestMapping("/")
	public String index() {
		return "index";
	}
	@RequestMapping("/login")
	public String loginPage() {
		return "login";
	}
	@RequestMapping(path="/loginBtn",method = RequestMethod.POST)
	public String Login(@RequestParam("email") String email,@RequestParam("password") String password) {
		
		User user1=userservice.findUserByEmail(email);
		
		if(user1.getUserEmail().equals(email) && user1.getUserPassword().equals(password))
		{
			System.out.println("User Credentials Matched");
			return "userDashboard";
		}
		else if(email.equals("admin@xyz.com") && password.equals("123"))
		{
			System.out.println("User Credentials Matched");
			return "adminDashboard";
		}
		else {
			System.out.println("User Credentials not Matched");
			return "login";
		}
	}
	@RequestMapping("/registration")
	public String registerPage() {
		return "registration";
	}
	@PostMapping("/registerBtn")
	public String Register(@RequestParam("name") String userName,@RequestParam("email") 
	String userEmail,@RequestParam("password") String userPassword,@RequestParam("city")
	String userCity,@RequestParam("state") String userState)
	{
		
		user.setUserName(userName);
		user.setUserEmail(userEmail);
		user.setUserPassword(userPassword);
		user.setUserCity(userCity);
		user.setUserState(userState);

		userservice.setUser(user);
		
		return "registration";
	}
}
